export type Tool = {
  slug: string;
  title: string;
  titleBn: string;
  description: string;
  category: 'calculator' | 'converter' | 'utility' | 'bd-services';
  icon: string;
};

export const tools: Tool[] = [
  {
    slug: 'age-calculator',
    title: 'Age Calculator',
    titleBn: 'বয়স ক্যালকুলেটর',
    description: 'Calculate exact age from birth date',
    category: 'calculator',
    icon: '🎂',
  },
  {
    slug: 'bmi-calculator',
    title: 'BMI Calculator',
    titleBn: 'বিএমআই ক্যালকুলেটর',
    description: 'Calculate Body Mass Index',
    category: 'calculator',
    icon: '⚖️',
  },
  // Add new tools here - AI must only add entry here
];
