import AgeCalculator from "@/components/tools/AgeCalculator";
export const metadata = { title: "Age Calculator - HubinBD" };
export default function Page() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 text-center">বয়স ক্যালকুলেটর - Age Calculator</h1>
      <AgeCalculator />
    </div>
  );
}
