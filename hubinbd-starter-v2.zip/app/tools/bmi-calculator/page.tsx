import BmiCalculator from "@/components/tools/BmiCalculator";
export default function Page(){ return <div><h1 className="text-2xl font-bold mb-6 text-center">BMI Calculator</h1><BmiCalculator/></div> }
