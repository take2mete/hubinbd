import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HubinBD - Bangladesh's Digital Hub",
  description: "Tools, Services & Resources for Bangladesh",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="bn">
      <body className="bg-[#0a0a0a] text-white min-h-screen">
        <header className="border-b border-zinc-800 p-4">
          <div className="max-w-6xl mx-auto flex justify-between items-center">
            <h1 className="text-xl font-bold">🇧🇩 HubinBD</h1>
            <a href="https://hubinbd.vercel.app" className="text-sm text-zinc-400">hubinbd.vercel.app</a>
          </div>
        </header>
        <main className="max-w-6xl mx-auto p-4 md:p-6">{children}</main>
      </body>
    </html>
  );
}
