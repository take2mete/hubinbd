import { tools } from "@/lib/tools";
import Link from "next/link";

export default function Home() {
  return (
    <div>
      <section className="py-10 text-center">
        <h2 className="text-4xl font-bold mb-3">Hub in BD</h2>
        <p className="text-zinc-400">Bangladesh&apos;s Digital Hub | Tools, Services & Resources</p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {tools.map((tool) => (
          <Link
            key={tool.slug}
            href={`/tools/${tool.slug}`}
            className="border border-zinc-800 rounded-xl p-5 hover:border-zinc-600 hover:bg-zinc-900 transition"
          >
            <div className="text-3xl mb-2">{tool.icon}</div>
            <h3 className="font-semibold">{tool.title}</h3>
            <p className="text-xs text-zinc-500">{tool.titleBn}</p>
            <p className="text-sm text-zinc-400 mt-2">{tool.description}</p>
          </Link>
        ))}
      </div>

      <div className="mt-10 border border-dashed border-zinc-800 rounded-xl p-6 text-center text-sm text-zinc-500">
        নতুন টুল যোগ করতে lib/tools.ts এ এন্ট্রি যোগ করুন - এক ফাইলে সব লিখবেন না
      </div>
    </div>
  );
}
