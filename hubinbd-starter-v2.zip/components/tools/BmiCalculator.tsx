"use client";
import { useState } from "react";
export default function BmiCalculator(){
  const [h,setH]=useState(""); const [w,setW]=useState(""); const [bmi,setBmi]=useState("");
  const calc=()=>{ const hm=Number(h)/100; const b=Number(w)/(hm*hm); setBmi(b.toFixed(2));}
  return (
    <div className="max-w-md mx-auto border border-zinc-800 rounded-xl p-6 bg-zinc-900">
      <input placeholder="উচ্চতা (cm)" value={h} onChange={e=>setH(e.target.value)} className="w-full p-3 rounded bg-black border border-zinc-700 mb-3"/>
      <input placeholder="ওজন (kg)" value={w} onChange={e=>setW(e.target.value)} className="w-full p-3 rounded bg-black border border-zinc-700"/>
      <button onClick={calc} className="w-full mt-4 bg-white text-black p-3 rounded font-semibold">BMI বের করুন</button>
      {bmi && <div className="mt-4 text-center text-xl font-bold">BMI: {bmi}</div>}
    </div>
  )
}
