"use client";
import { useState } from "react";

export default function AgeCalculator() {
  const [dob, setDob] = useState("");
  const [result, setResult] = useState("");

  const calc = () => {
    if (!dob) return;
    const birth = new Date(dob);
    const now = new Date();
    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    if (months < 0) { years--; months += 12; }
    setResult(`${years} বছর, ${months} মাস`);
  };

  return (
    <div className="max-w-md mx-auto border border-zinc-800 rounded-xl p-6 bg-zinc-900">
      <input type="date" value={dob} onChange={e=>setDob(e.target.value)} className="w-full p-3 rounded bg-black border border-zinc-700 text-white" />
      <button onClick={calc} className="w-full mt-4 bg-white text-black p-3 rounded font-semibold">হিসাব করুন</button>
      {result && <div className="mt-4 text-center text-xl font-bold">{result}</div>}
    </div>
  );
}
